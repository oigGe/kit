package georggross;

import edu.kit.informatik.Terminal;

public class Main {

    private static boolean isRunning = true;

    public static void main(String[] args) {

        if (!FormatChecker.isCorrectCommandlineArgument(args)) {
            Terminal.printError("invalid command line arguments. ");
            isRunning = false;
        }
        boolean isTorus = isTorus(args);
        int size = Integer.parseInt(args[1]);
        App app = new App(size, isTorus);
        while (isRunning) {
            start(app);
            if (!isRunning) {
                break;
            }
            turns(app);
            if (!isRunning) {
                break;
            }
            after(app);

        }
    }


    private static void after(App app) {
        boolean isAfter = true;
        while (isAfter) {
            if (!isRunning) {
                break;
            }
            String input = Terminal.readLine();
            if (FormatChecker.isQuit(input)) {
                isRunning = false;
                break;
            } else if (FormatChecker.isPrintCell(app.getSize(), input, app.isTorus)) {
                printCell(app, input);
            } else if (FormatChecker.isPrint(input)) {
                app.getBoard().printBoard();
            }
        }
    }


    private static void start(App app) {
        boolean hasStarted = false;
        while (!hasStarted) {
            String input = Terminal.readLine();
            if (FormatChecker.isStart(app.getSize(), input)) {
                int[] playerAPositions = InputFormat.playerStartValues(input, 0);
                int[] playerBPositions = InputFormat.playerStartValues(input, 1);
                app.start(playerAPositions, playerBPositions);
                hasStarted = true;
            } else if (FormatChecker.isPrint(input)) {
                app.getBoard().printBoard();
            } else if (FormatChecker.isPrintCell(app.getSize(), input, app.isTorus)) {
                int[] coordinates = InputFormat.getCellCoordinates(input);
                app.getBoard().printCell(coordinates[0], coordinates[1]);
            } else if (FormatChecker.isQuit(input)) {
                isRunning = false;
                break;
            } else {
                Terminal.printError("invalid input");
            }
        }
    }

    private static void turns(App app) {
        boolean gameOver = false;
        initiateTurns(app);
        while (!gameOver) {
            if (!isRunning) {
                break;
            } else if (app.getPlayerA().isTurn()) {
                turn(app, app.getPlayerA());
                if (isGameOver(app)) {
                    printWinner(app);
                    break;
                }
                switchTurns(app);
            } else {
                turn(app, app.getPlayerB());
                if (isGameOver(app)) {
                    printWinner(app);
                    break;
                }
                ;
                switchTurns(app);
            }
        }
    }




    private static void printWinner(App app){
        if (app.getPlayerA().hasWon(app.getBoard())  || app.getPlayerB().hasLost()){
            Terminal.printLine("P1 wins");
        }else if (app.getPlayerB().hasWon(app.getBoard()) || app.getPlayerA().hasLost()){
            Terminal.printLine("P2 wins");
        }
    }


    private static void turn(App app, Player player) {
        int roll = rollPhase(app, player);
        movePhase(app, player, roll);
    }

    private static void movePhase(App app, Player player, int roll) {
        boolean isMoving = true;
        while (isMoving) {
            if (!isRunning) {
                break;
            }
            String input = Terminal.readLine();
            if (FormatChecker.isMove(app.getSize(), app.isTorus, input)) {
                int whichStone = InputFormat.getStoneToMove(input);
                int[] coordinates = InputFormat.getStoneMoveCoordinates(input);
                if (player.moveStone(whichStone, roll, coordinates[0], coordinates[1], app)) {
                    if (!isGameOver(app)) {
                        Terminal.printLine("OK");
                    }
                    isMoving = false;
                } else {
                    Terminal.printError("invalid move input.");
                }
            } else if (FormatChecker.isPrint(input)) {
                app.getBoard().printBoard();
            } else if (FormatChecker.isPrintCell(app.getSize(), input, app.isTorus)) {
                printCell(app, input);
            } else if (FormatChecker.isToken(input)) {
                player.printToken();
            } else if (FormatChecker.isQuit(input)) {
                isRunning = false;
                isMoving = false;
            } else {
                Terminal.printError("invalid command in move Phase");
            }

        }
    }


    private static int rollPhase(App app, Player player) {
        boolean hasRolled = false;
        int roll = -1;
        while (!hasRolled) {
            if (!isRunning) {
                break;
            }
            String input = Terminal.readLine();
            if (FormatChecker.isRoll(app.getSize(), input)) {
                roll = InputFormat.getRoll(input);
                hasRolled = true;
            } else if (FormatChecker.isQuit(input)) {
                isRunning = false;
                hasRolled = false;
                break;
            } else if (FormatChecker.isPrintCell(app.getSize(), input, app.isTorus)) {
                printCell(app, input);
            } else if (FormatChecker.isPrint(input)) {
                app.getBoard().printBoard();
            } else if (FormatChecker.isToken(input)) {
                player.printToken();
            } else {
                Terminal.printError("invalid command");
            }
        }
        return roll;
    }


    private static void printCell(App app, String input) {
        int[] coordinates = InputFormat.getCellCoordinates(input);
        app.getBoard().printCell(coordinates[0], coordinates[1]);
    }



    private static boolean isGameOver(App app) {
        if (app.getPlayerA().hasWon(app.getBoard()) || app.getPlayerB().hasLost()) {
            return true;
        } else if (app.getPlayerB().hasWon(app.getBoard()) || app.getPlayerA().hasLost()) {
            return true;
        }
        return false;
    }


    private static void initiateTurns(App app) {
        app.getPlayerA().setTurn(true);
        app.getPlayerB().setTurn(false);
    }

    private static void switchTurns(App app) {
        app.getPlayerA().setTurn(!app.getPlayerA().isTurn());
        app.getPlayerB().setTurn(!app.getPlayerB().isTurn());
    }

    private static boolean isTorus(String[] args) {
        if (args[0].equals("torus")) {
            return true;
        }
        return false;
    }
}
